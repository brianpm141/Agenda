// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDplmMzrRxrB1KoaXy0qZZJ7hfHrhslZ3c",
  authDomain: "agendaapp-ff8f4.firebaseapp.com",
  projectId: "agendaapp-ff8f4",
  storageBucket: "agendaapp-ff8f4.firebasestorage.app",
  messagingSenderId: "604855127757",
  appId: "1:604855127757:web:61bedd48ef63ddbdf0e384"
};

// Initialize Firebase
export default app = initializeApp(firebaseConfig);